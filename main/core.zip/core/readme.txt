This folder is the internal framework of FirePack and this is used by many different packs. Deleting this will result in most packs not working as expected or never working.

about the folders:

1: internals

This folder is specifically for scripts that are part of FirePack and is not meant to be used by any other script. (these include optimization scripts, UI scripts, etc..)

2: script_modules

This folder contains scripts that can be used by other scripts (including resource packs) as modules for better results.